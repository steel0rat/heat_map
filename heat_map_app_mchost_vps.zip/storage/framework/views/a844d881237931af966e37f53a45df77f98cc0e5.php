<?php $__env->startSection('content'); ?>
    <div class="container_map_base">
            <?php $__currentLoopData = $url_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="heat_site_parent_block">
                    <div style="background-image: url('<?php echo e($domen['img']); ?>');" class="heat_site_block">
                        <div class="heat_name_domen"><?php echo e($domen['domen']); ?></div>
                    </div>
                    <div class="heat_container_of_url">
                        <?php $__currentLoopData = $domen['url']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('map_route')); ?>/map?url=<?php echo e($url); ?>"><?php echo e($url); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/httpd/vhosts/test-heat-map.mcdir.ru/httpdocs/resources/views/map_home.blade.php ENDPATH**/ ?>
    <footer class="container">
        <a class="footer-a-me" href="https://vk.com/mr_steel_rat">© 2021 Gazin Maxim </a>
    </footer>
<?php /**PATH /home/httpd/vhosts/test-heat-map.mcdir.ru/httpdocs/resources/views/inc/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
        <div class="heat_map_script_div">
            <div class="heat_map_script"><?php if($src != ''): ?>&lt;script src="<?php echo e($src); ?>"&gt;&lt;/script&gt;<?php else: ?> не сгенерирован <?php endif; ?></div>
            <a href="<?php echo e(route('map_script')); ?>/?generate_script" class="heat_map_script_gen">Сгенерировать скрипт</a>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\PhpstormProjects\heat_map_scanner\heat_map_app\resources\views/map_script.blade.php ENDPATH**/ ?>
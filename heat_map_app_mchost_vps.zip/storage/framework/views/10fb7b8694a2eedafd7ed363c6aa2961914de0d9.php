    

    <?php $__env->startSection('content'); ?>
        <div class="container">
            <?php if($db_flag): ?>
                <div class="home_db_state home_db_state_gr">Соединение с базой данных установлено, можно тестировать</div>
                <div class="home_features container_map_base">
                    <a href="<?php echo e(route('map_script')); ?>" class="heat_site_parent_block">
                        <div style="background-image: url('/storage/home/home_script.png');" class="heat_site_block">
                            <div class="heat_name_domen">Установите скрипт</div>
                        </div>
                    </a>
                    <a href="<?php echo e(route('map_route')); ?>" class="heat_site_parent_block">
                        <div style="background-image: url('/storage/home/home_map.png');" class="heat_site_block">
                            <div class="heat_name_domen">Посмотрите результат</div>
                        </div>
                    </a>
                    <a href="<?php echo e(route('about')); ?>" class="heat_site_parent_block">
                        <div style="background-image: url('/storage/home/home_project.png');" class="heat_site_block">
                            <div class="heat_name_domen">О проекте</div>
                        </div>
                    </a>
                </div>
            <?php else: ?>
                <div class="home_db_state home_db_state_r">Проверьте соединение с базой данных</div>
            <?php endif; ?>
                <h1 class="text-white">Тестовое задание PHP</h1>
                <h3 class="text-white">Тепловая карта кликов на сайте и анализ активности пользвателей</h3>
                <h5 class="text-white">Разработанно в рамках тестового задания RB1</h5>
        </div>
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/httpd/vhosts/test-heat-map.mcdir.ru/httpdocs/resources/views/home.blade.php ENDPATH**/ ?>
<?php dd; ?>(($items)

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\PhpstormProjects\heat_map_scanner\heat_map_app\resources\views/map_base.blade.php ENDPATH**/ ?>
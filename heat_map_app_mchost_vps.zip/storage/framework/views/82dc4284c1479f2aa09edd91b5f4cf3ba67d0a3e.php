<table>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->url); ?></td>
        <td><?php echo e($item->x_coord); ?></td>
        <td><?php echo e($item->y_coord); ?></td>
        <td><?php echo e($item->ip); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\Users\Admin\PhpstormProjects\heat_map_scanner\heat_map_app\resources\views/heat_map/index.blade.php ENDPATH**/ ?>
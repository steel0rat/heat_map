function getPosition(e){ // отслеживание координаты клика с учётом скролла страницы

    var x = 0;
    var y = 0;
    if (!e) {
        var e = window.event;
    }
    var max_x = document.documentElement.scrollWidth; //максимальные размеры страницы
    var max_y = Math.max(
        document.body.scrollHeight, document.documentElement.scrollHeight,
        document.body.offsetHeight, document.documentElement.offsetHeight,
        document.body.clientHeight, document.documentElement.clientHeight
    );
    if (e.pageX || e.pageY){
        x = e.pageX;
        y = e.pageY;
    } else if (e.clientX || e.clientY){
        x = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
        y = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
    }

    let time_arr = [x,y,max_x,max_y];
    // return {x: x, y: y}
    return time_arr;
}

function get_nice_date() { // удобный вывод даты
    var now_date_check_click = new Date();
    return now_date_check_click.getFullYear() + '-' + now_date_check_click.getMonth() + '-' + now_date_check_click.getDate() + ' ' + now_date_check_click.getHours() + '.' + now_date_check_click.getMinutes()+ '.' + now_date_check_click.getSeconds();
}

var start_time_check_click = get_nice_date();    // прочтём дату и время загрузки страницы
var time_coord_mass = [];                        // массив для хранения данных о дате и координатах клика

document.addEventListener("click",function(event) { // добавим слушатель клика
    let time_arr = [getPosition(),get_nice_date()];
    time_coord_mass.push(time_arr);
});


// подготовим отправку результатов при закрытии страницы
var _wasPageCleanedUp = false;
$(window).on('beforeunload', function () {
    send_info_check_js(); //для Chrome
});
$(window).on("unload", function () {
    send_info_check_js(); //для остальных браузеров кроме Оперы, с ней вообще не работает отправка при самовольном закрытии страницы
});

//при готовом DOM кинем event на все ссылки для отправки данных на сервер
$(document).ready(function() {
    set_all_of_a_send();
});
function set_all_of_a_send() {
    let hrefs_check = document.getElementsByTagName('a');
    for (let hr_check of hrefs_check) {
        hr_check.addEventListener("click", function(){ send_info_check_js(); });
    }
}


// сама функция отправки данных к нам на сервер для обработки
function send_info_check_js() {
    if (!_wasPageCleanedUp) {
        $.ajax({
            url: 'http://127.0.0.1:8000/storage/script/check_js.js',
            method: 'post',
            type: 'post',
            data: {form_data: time_coord_mass, started_time: start_time_check_click, ended_time: get_nice_date()},
            success: function (json) {
                _wasPageCleanedUp = true;
            }
        });
    }
}

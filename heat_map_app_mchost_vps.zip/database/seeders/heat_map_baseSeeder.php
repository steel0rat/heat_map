<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;
class heat_map_baseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */


    public function run()
    {
        //
        $random_coords = [];
        for ($i = 1; $i <= 5000; $i++) {
            $dom = get_any_domen();
            $url = 'https://'.$dom.get_any_url($dom);
            $random_coords[] = [
                'domen'     => $dom,
                'url'       => $url,
                'max_x'     => rand(800, 1900),
                'max_y'     => rand(100, 1000),
                'x_coord'   => rand(-600, 600),
                'y_coord'   => rand(1, 1500),
                'date_time' => date('Y-m-').rand(date('d')-1, date('d')).' '.rand(0,23).':'.rand(0,59).':'.rand(0,59),
                'much'      => 1,
                'ip'        => '127.0.0.1',
            ];
        }

        DB::table('heat_map_bases')->insert($random_coords);

    }


}
function get_any_url($dom) {
    if ($dom == 'vk.com'){
        return '/mr_steel_rat';
    } else {
        return '/';
    }

}
function get_any_domen() {
    $i = rand(1,2);
    switch ($i) {
        case 1:
            return 'vk.com';
        case 2:
            return 'localhost';

    }
}

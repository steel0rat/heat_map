const mix = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel applications. By default, we are compiling the CSS
 | file for the application as well as bundling up all the JS files.
 |
 */

//mix.js('resources/js/app.js', 'public/js')

mix.scripts(['resources/js/jquerry.min.js','resources/js/app.js'], 'public/js/all.js');
mix.scripts(['resources/js/simpleheat.js','resources/js/primeheat.js'], 'public/js/map.js');

mix.postCss('resources/css/app.css', 'public/css', [
        //
    ]);

function show_heat_map(url) {
    console.log(url);
    nice_hide_container();
    heat.clear();
    load_heat_map(url);
}

function set_loader() {
    $('.container_canvas').css('backgroundImage', 'url("https://sporttime.online/ready_heat/loading.gif")');
}

function load_heat_map(url) {
    $('.container_canvas').css('backgroundImage', 'url('+url+')');
    draw();
}

function get(id) {
    return document.getElementById(id);
}

function draw() {
    heat.draw();
    frame = null;
}




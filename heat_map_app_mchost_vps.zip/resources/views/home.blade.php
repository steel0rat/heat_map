
    @extends('layouts.app')

    @section('content')
        <div class="container">
            @if($db_flag)
                <div class="home_db_state home_db_state_gr">Соединение с базой данных установлено, можно тестировать</div>
                <div class="home_features container_map_base">
                    <a href="{{ route('map_script') }}" class="heat_site_parent_block">
                        <div style="background-image: url('/storage/home/home_script.png');" class="heat_site_block">
                            <div class="heat_name_domen">Установите скрипт</div>
                        </div>
                    </a>
                    <a href="{{ route('map_route') }}" class="heat_site_parent_block">
                        <div style="background-image: url('/storage/home/home_map.png');" class="heat_site_block">
                            <div class="heat_name_domen">Посмотрите результат</div>
                        </div>
                    </a>
                    <a href="{{ route('about') }}" class="heat_site_parent_block">
                        <div style="background-image: url('/storage/home/home_project.png');" class="heat_site_block">
                            <div class="heat_name_domen">О проекте</div>
                        </div>
                    </a>
                </div>
            @else
                <div class="home_db_state home_db_state_r">Проверьте соединение с базой данных</div>
            @endif
                <h1 class="text-white">Тестовое задание PHP</h1>
                <h3 class="text-white">Тепловая карта кликов на сайте и анализ активности пользвателей</h3>
                <h5 class="text-white">Разработанно в рамках тестового задания RB1</h5>
        </div>
    @endsection



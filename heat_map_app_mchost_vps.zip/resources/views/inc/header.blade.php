<header>
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 box-shadow heat_map_head_div">
        <h5 class="my-0 mr-md-auto font-weight-normal text-white">Heat map scanner App</h5>
        <nav class="my-2 my-md-0 mr-md-3">
            <a class="p-2  header_nav_a" href="/">Главная</a>
            <a class="p-2  header_nav_a" href="{{ route('map_route') }}">Тепловые карты</a>
            <a class="p-2  header_nav_a" href="{{ route('map_script') }}">Скрипт</a>
            <a class="p-2  header_nav_a" href="{{ route('about') }}">О приложении</a>
        </nav>
</header>

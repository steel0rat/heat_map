@extends('layouts.app')


@section('content')
    <div class="container_map_base">
            @foreach( $url_arr as $domen)
                <div class="heat_site_parent_block">
                    <div style="background-image: url('{{ $domen['img'] }}');" class="heat_site_block">
                        <div class="heat_name_domen">{{ $domen['domen'] }}</div>
                    </div>
                    <div class="heat_container_of_url">
                        @foreach( $domen['url'] as $url)
                            <a href="{{route('map_route')}}/map?url={{ $url }}">{{ $url }}</a>
                        @endforeach
                    </div>
                </div>
            @endforeach
    </div>
@endsection

<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','App\Http\Controllers\HeatMapController@home_page')->name('home');

Route::get('/about', function () {
    return view('about');
})->name('about');



Route::get('/map','App\Http\Controllers\HeatMapController@index')->name('map_route');
Route::get('/map/script','App\Http\Controllers\HeatMapController@get_script')->name('map_script');
Route::get('/map/{alias}','App\Http\Controllers\HeatMapController@show_map')->where('alias', '.*');;



Route::post('/HeatMapApi','App\Http\Controllers\heat_map_register_click@registrate');

//Route::resource('heat_map', 'App\Http\Controllers\heat_map_app')->names('heat_map');


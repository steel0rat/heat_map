<?php


namespace App\Http\Controllers;

use App\Models\Heat_map_model;
use Illuminate\Http\Request;
use DB;

class heat_map_register_click extends Controller{

    public function registrate(Request $req) {
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        header('Access-Control-Allow-Credentials: true');
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = @$_SERVER['REMOTE_ADDR'];

        if(filter_var($client, FILTER_VALIDATE_IP)) $ip = $client;
        elseif(filter_var($forward, FILTER_VALIDATE_IP)) $ip = $forward;
        else $ip = $remote;


        foreach($req->input('form_data') as $row){
            $row_coords = new Heat_map_model();
            $row_coords->domen      = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
            $row_coords->url        = $_SERVER['HTTP_REFERER'];
            $row_coords->x_coord    = $row[0][0];
            $row_coords->y_coord    = $row[0][1];
            $row_coords->max_x      = $row[0][2];
            $row_coords->max_y      = $row[0][3];
            $row_coords->date_time  = $row[1];
            $row_coords->much       = 1;
            $row_coords->ip         = $ip;
            $row_coords->save();
        }
        print_r($req->input('form_data'));
    }
}

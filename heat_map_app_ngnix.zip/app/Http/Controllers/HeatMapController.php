<?php

namespace App\Http\Controllers;

use App\Models\Heat_map_model;
use Illuminate\Http\Request;
use DB;
class HeatMapController extends Controller
{
    //
    public function index() //получим все уникальные url из базы, а затем сформируем массив
    {
        $items = Heat_map_model::select('domen','url')->distinct('url')->get();
        $url_arr = array();
        if (count($items)) {
            foreach ($items as $el){
                $url_arr[$el->domen]['domen']   = $el->domen;
                $url_arr[$el->domen]['img']     = get_image_of_host('http://'.$el->domen, 1200,false, true)['url'];
                $url_arr[$el->domen]['url'][]   = $el->url;
            }
        } else {
                $url_arr['затычка']['domen']   = 'Пока пусто';
                $url_arr['затычка']['img']     = get_image_of_host('', 1200,false, false)['url'];
                $url_arr['затычка']['url'][]   = '';
        }
        return view('map_home', compact(['items','url_arr']));

    }

    public function show_map($urll)
    {
        if(isset($_GET['url'])){$url = $_GET['url'];}else {$url = $urll;}//адаптируем под VPS хостинги, где nginx нельзя поправить
        date_default_timezone_set('Europe/Moscow'); //переведем часовой пояс на наш
        $items_date = Heat_map_model::select('date_time')->whereRaw("(date_time > NOW() - INTERVAL 23 HOUR AND date_time < NOW()) AND url = '".$url.'/'."' or url ='".$url."'  ")->get();
        $date_time_data_raw = [];
        $date_time_data_raw['t'.str_pad(date('H')+1, 2, "0", STR_PAD_LEFT)] = [
            'hour'  => str_pad(date('H')+1, 2, "0", STR_PAD_LEFT),
            'min'   => date('i'),
            'much'  => 0
        ]; // создадим массив для графика
        for($i = date('H')+2; $i <= 23; $i++){
            $date_time_data_raw['t'.str_pad($i, 2, "0", STR_PAD_LEFT)] = [
                'hour'  => str_pad($i, 2, "0", STR_PAD_LEFT),
                'min'   => '00',
                'much'  => 0
            ];
        }
        for($i = 0; $i < date('H'); $i++){
            $date_time_data_raw['t'.str_pad($i, 2, "0", STR_PAD_LEFT)] = [
                'hour'  => str_pad($i, 2, "0", STR_PAD_LEFT),
                'min'   => '00',
                'much'  => 0
            ];
        }
        $date_time_data_raw['t'.str_pad(date('H'), 2, "0", STR_PAD_LEFT)] = [
            'hour'  => str_pad(date('H'), 2, "0", STR_PAD_LEFT),
            'min'   => date('i'),
            'much'  => 0
        ];// этими циклами заполним массив, начиная с часа, который сейчас идет
        foreach ($items_date as $time) {
            $date_time_data_raw['t'.substr($time->date_time, -8, 2)]['much']++;
        }// подсчитаем клики
        $date_time_count = count($items_date);


        // тут получим все координаты, закинем в массив
        $items = Heat_map_model::whereRaw("url = '".$url.'/'."' or url ='".$url."'")->get();
        $coords_data = "";
        if (count($items) > 0) {
            $need_img = true;
            foreach ($items as $item) {
                $x_coord = round(1200/2 + (int)$item->x_coord, 0);// подсчёт по оси x идёт от центра, чтобы избежать проблемы с искажением
                $y_coord = $item->y_coord;
                $c_much = $item->much;
                $coords_data .= "[".$x_coord.",".$y_coord.",".$c_much.",],";
            }
        } else {
            $need_img = false;
        }
        $img = get_image_of_host($url.'/',1200,isset($_GET['refresh']),$need_img);// запросим фото, если есть координаты, то скриншот, если нет, то заглушку

        return view('map_show', compact(['url','coords_data','img','date_time_data_raw','date_time_count']));
    }

    public function get_script(){ // страница скрипта, если есть запрос, то сгенерируем, подменив url для ajax из исходного скрипта на наш текущий сервер
        if(isset($_GET['generate_script'])){
            $raw_script = @file_get_contents($_SERVER['DOCUMENT_ROOT']."\heat_map_helper\check_js.js");
            $my_api_host = "'".(!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] ."/HeatMapApi"."'";
            $ready_script = str_replace("--HereAddUrl--", $my_api_host, $raw_script);
            $OpenFile = fopen($_SERVER['DOCUMENT_ROOT']."\storage\script\check_js.js", "w+");
            $Write = fwrite($OpenFile, $ready_script);

        }
        if(file_exists ($_SERVER['DOCUMENT_ROOT'] . "\storage\script\check_js.js")){ //если скрипт сгенерирован, то дадим ссылку на него, если нет, то пусто
            $src = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] ."/storage/script/check_js.js";
        } else {
            $src = "";
        }
        return view('map_script', compact(['src']));
    }

    public function home_page(){
        $db_flag = true;
        try {
            DB::connection()->getPdo(); // тут проверяем соединение с базой данных
        } catch (\Exception $e) {
          $db_flag = false;
        }
        return view('home', compact(['db_flag']));
    }
}

function get_image_of_host($post_link, $post_width,$need_new,$need_img){ // функция генерации скриншота
    $url_for_image = '/storage/empty.png';
    $size_of_png = [1200,600];
    if ($need_img) {
        $some_url = str_replace("://", "___", $post_link);
        $some_url = str_replace("/", "_", $some_url);
        $some_url = str_replace(".", "_dot_", $some_url); //тут обработаем поступивший url
        $Filename = $some_url . $post_width . ".png";
        $ScreenshotDirectory = $_SERVER['DOCUMENT_ROOT'] . "\storage\screens_for_heat\\";
        if (!(@is_file($ScreenshotDirectory . $Filename) or $need_new)) {
            if ($Image = @file_get_contents("https://api.s-shot.ru/" . $post_width . "x0/PNG/1280/Z100/?" . $post_link)) { //тут два api на случай, если будет запрошено много и api ограничит доступ на время
                $OpenFile = fopen($ScreenshotDirectory . $Filename, "w+");
                $Write = fwrite($OpenFile, $Image);
            } elseif ($Image = @file_get_contents("https://mini.s-shot.ru/" . $post_width . "x0/PNG/1280/Z100/?" . $post_link)) {
                $OpenFile = fopen($ScreenshotDirectory . $Filename, "w+");
                $Write = fwrite($OpenFile, $Image);
            }
        }
        if (file_exists ($ScreenshotDirectory . $Filename)) { // тут узнаем размеры картинки
            $url_for_image = '/storage/screens_for_heat/' . $Filename;
            $size_of_png = getimagesize($ScreenshotDirectory . $Filename);
        }
    }
    return  array(
        "url"   =>  $url_for_image,
        "size"  =>  $size_of_png
    );
}

function getPosition(e){ // отслеживание координаты клика с учётом скролла страницы
    var x = 0;
    var y = 0;
    if (!e) {
        var e = window.event;
    }
    var max_x = document.documentElement.scrollWidth; //максимальные размеры страницы
    var max_y = Math.max(
        document.body.scrollHeight, document.documentElement.scrollHeight,
        document.body.offsetHeight, document.documentElement.offsetHeight,
        document.body.clientHeight, document.documentElement.clientHeight
    );
    if (e.pageX || e.pageY){
        x = e.pageX;
        y = e.pageY;
    } else if (e.clientX || e.clientY){
        x = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
        y = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
    }
    x = Math.round(x - max_x/2); //будем считать расстояние от центра
    let time_arr = [x,y,max_x,max_y];
    // return {x: x, y: y}
    console.log(x+' '+y);
    return time_arr;
}

function get_nice_date() { // удобный вывод даты
    var now_date_check_click = new Date();
    return now_date_check_click.getFullYear() + '-' + now_date_check_click.getMonth() + '-' + now_date_check_click.getDate() + ' ' + now_date_check_click.getHours() + '.' + now_date_check_click.getMinutes()+ '.' + now_date_check_click.getSeconds();
}

var start_time_check_click = get_nice_date();    // прочтём дату и время загрузки страницы
var time_coord_mass = [];                        // массив для хранения данных о дате и координатах клика

document.addEventListener("click",function(event) { // добавим слушатель клика
    registrate_click();
});

function registrate_click(){
    let time_arr = [getPosition(),get_nice_date()];
    time_coord_mass.push(time_arr);
}
// подготовим отправку результатов при закрытии страницы
$(window).on('beforeunload', function () {
    send_info_check_js_ex(); //для Chrome
});
$(window).on("unload", function () {
    send_info_check_js_ex(); //для остальных браузеров кроме Оперы, с ней вообще не работает отправка при самовольном закрытии страницы
});

//при готовом DOM кинем event на все ссылки для отправки данных на сервер
$(document).ready(function() {
    set_all_of_a_send();
    document.addEventListener("click", function(){ set_all_of_a_send(); });
});

var check_all_atached = false;
function set_all_of_a_send() {
    if(!check_all_atached) {
        console.log('atached');
        let hrefs_check = document.getElementsByTagName('a');
        for (let hr_check of hrefs_check) {
            hr_check.addEventListener("click", function (e) {
                registrate_click();
                e.preventDefault();
                send_info_check_js(e);
            });
        }
        check_all_atached = true;
    }
}



var send_info_sended = false;
function send_info_check_js(el) {// функция отправки данных к нам на сервер для обработки при переходе по ссылке
    console.log('try');
    if(!send_info_sended) {
        console.log('sended');
        console.log(time_coord_mass);
        $.ajax({
            url: --HereAddUrl--,
            method: 'post',
            type: 'post',
            data: {form_data: time_coord_mass, started_time: start_time_check_click, ended_time: get_nice_date()},
            success: function (json) {
                console.log('resieved'+json);
                window.location = el.target.href;
            }
        });
        send_info_sended = true;
    }
}

function send_info_check_js_ex() {// функция отправки данных к нам на сервер для обработки при закрытии окна
    if(!send_info_sended) {
        $.ajax({
            url: --HereAddUrl--,
            method: 'post',
            type: 'post',
            data: {form_data: time_coord_mass, started_time: start_time_check_click, ended_time: get_nice_date()},
            success: function (json) {
                console.log('resieved'+json);
            }
        });
        send_info_sended = true;
    }
}

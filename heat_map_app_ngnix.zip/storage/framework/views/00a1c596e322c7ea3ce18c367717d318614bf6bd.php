<?php $__env->startSection('head_add'); ?>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script src="/js/map.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div id="heat_map_container"  onload="alert('ready')" class="heat_container container_canvas ">

    <a class="back_to_site_button" href="/map">Вернутся</a>
    <div class="heat_options">
        <label>Radius </label><input type="range" id="radius" value="2" min="1" max="50" /><br />
        <label>Blur </label><input type="range" id="blur" value="2" min="1" max="50" />
    </div>
    <canvas id="canvas" width="1200px" height="<?php echo e($img['size'][1]); ?>;"></canvas>
</div>

<?php if( $date_time_count != 0): ?>
<div id="curve_chart" style="width: 1200px; height: 500px"></div>
<script>
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([['время', 'клики'],<?php $__currentLoopData = $date_time_data_raw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> ['<?php echo e($el['hour']); ?>:<?php echo e($el['min']); ?>',<?php echo e($el['much']); ?>], <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>]);

            var options = {
                title: 'Количество кликов за последние 24 часа',
                curveType: 'function',
                legend: 'none',
                backgroundColor: '#1D1D1D',
                titleTextStyle: {
                    color: '#FFF',
                    fontSize:  16,
                    textAlign: 'center'
                  },
                hAxis: {
                    textStyle:{
                        color: '#FFF',
                        fontSize: 8,
                        bold: true
                    }
                },
                vAxis: {
                    textStyle:{
                        color: '#FFF',
                        fontSize: 14,
                        bold: true
                    }
                },


            };


            var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

            chart.draw(data, options);
        }
</script>
<?php else: ?>
    <div class="text-center text-white">за последние 24 часа кликов не было</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('load_func'); ?>
   load_heat_map('<?php echo e($img['url']); ?>');
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot_add'); ?>
    <script>
        var data = [<?php echo e($coords_data); ?>];
        var heat = simpleheat('canvas').data(data).max(1),
            frame;
        heat.radius(2,2);
        var radius = get('radius'),
            blur = get('blur'),
            changeType = 'oninput' in radius ? 'oninput' : 'onchange';
        radius[changeType] = blur[changeType] = function (e) {
            heat.radius(+radius.value, +blur.value);
            frame = frame || window.requestAnimationFrame(draw);
        };
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\PhpstormProjects\heat_map_scanner\heat_map_app\resources\views/map_show.blade.php ENDPATH**/ ?>
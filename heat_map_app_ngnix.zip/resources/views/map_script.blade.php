@extends('layouts.app')

@section('content')
        <div class="heat_map_script_div">
            <div class="heat_map_script">@if($src != '')&lt;script src="{{ $src }}"&gt;&lt;/script&gt;@else не сгенерирован @endif</div>
            <a href="{{ route('map_script') }}/?generate_script" class="heat_map_script_gen">Сгенерировать скрипт</a>
        </div>
@endsection
